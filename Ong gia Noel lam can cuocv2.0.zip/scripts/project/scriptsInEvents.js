


const scriptsInEvents = {

	async Level1_Event1(runtime, localVars)
	{
		
	}

};

self.C3.ScriptsInEvents = scriptsInEvents;

